module.exports ={
    get: ()=> {},
    patch:()=>{},
    delete:()=>{},
    
}