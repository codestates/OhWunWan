module.exports={
    auth_controller: require('./auth') ,
    user_controller: require('./user'),
    post_controller: require('./post'),
    comment_controller: require('./comment'),
    like_controller: require('./like'),
    respect_controller: require('./respect'),
}