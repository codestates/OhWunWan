module.exports ={
    ohwunwuan_like:require('./ohwunwanLike'),
    feedback_like:require('./feedbackLike'),
}