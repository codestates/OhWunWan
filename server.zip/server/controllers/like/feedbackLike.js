module.exports={

    post :()=>{},//feedback 게시물 좋아요
    delete :()=>{}//feedback 게시물 좋아요 취소
}