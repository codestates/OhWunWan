const{Ohwunwan_like}=require('../../models')

module.exports={
    post :async (req,res)=>{
        const{ohwunwan_id,user_id}=req.body
        const ohwunwan_like =await Ohwunwan_like.create({ohwunwan_id,user_id})
        console.log(ohwunwan_like.dataValues)
        res.json({me:'good'})
    },//ohwunwan 게시물 좋아요
    delete :()=>{}//ohwunwan 게시물 좋아요 취소
}