module.exports ={
    
    ohwunwan:require('./ohwunwan.js'),
    feedback: require('./feedback.js'),
    bench_1rm: require('./bench1rm.js'),
    dead_1rm: require('./dead1rm.js'),
    squat_1rm: require('./squat1rm.js'),
    
}