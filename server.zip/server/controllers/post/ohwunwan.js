const { Ohwunwan,Ohwunwan_comment,User } = require('../../models');


module.exports = {
    //ohwunwan게시물 조회
    get: async (req, res) => {
        const{count}=req.params
        console.log('count:',count)
        const ohwunwan_count =await Ohwunwan.count()
        // console.log('ohwunwan_count:',ohwunwan_count)
        const ohwunwans=  await Ohwunwan_comment.findAll({
            include: [
                {
                  model: User,
                },
                {
                  model: Ohwunwan,
                
                },
              ],
          });
        const maped=ohwunwans.map(ohwunwan=>{
            return ohwunwan.dataValues
        })
        console.log(maped)
        res.json({message:'ok'})

    },
    //ohwunwan게시물 생성
    post: async (req, res) => {
        try {
            if (!Boolean(req.body.user_id && req.body.text_content && req.body.location)) return res.status(400).json({ message: 'Bad Request!' })
            const { user_id, text_content } = req.body
            // console.log('::::::::::::::::user_id:', user_id)
            const { location } = req.file
            // console.log(':::::::::::::location:',location)
            const post_info = {
                user_id,
                text_content,
                picture: location
            }
            await Ohwunwan.create(post_info);

            res.status(201).json({ message: 'The post has been created' })
        }
         catch (err) {
            res.status(500).json({ message: 'Server Error!' })
        }
    },//ohwunwan게시묵 작성
    patch: () => { },//ohwunwan게시물 수정
    delete: () => { },//ohwunwan게시물 삭제
}


