module.exports={
    get:()=>{}, //feedback게시물 조회
    post:()=>{},//feedback게시묵 작성
    patch:()=>{},//feedback게시물 수정
    delete:()=>{},//feedback게시물 삭제
}