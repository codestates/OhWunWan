module.exports={
    get:()=>{}, //squat1rm게시물 조회
    post:()=>{},//squat1rm게시묵 작성
    patch:()=>{},//squat1rm게시물 수정
    delete:()=>{},//squat1rm게시물 삭제
}