module.exports={
    get:()=>{}, //bench1rm게시물 조회
    post:()=>{},//bench1rm게시묵 작성
    patch:()=>{},//bench1rm게시물 수정
    delete:()=>{},//bench1rm게시물 삭제
}