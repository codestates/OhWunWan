module.exports={
    get:()=>{}, //dead1rm게시물 조회
    post:()=>{},//dead1rm게시묵 작성
    patch:()=>{},//dead1rm게시물 수정
    delete:()=>{},//dead1rm게시물 삭제
}