module.exports={
    post:()=>{}, //squat_1rm_respect  
    delete:()=>{} //squat_1rm_respect
}