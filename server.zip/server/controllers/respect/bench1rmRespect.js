module.exports={
    post:()=>{},//bench_1rm_respect
    delete:()=>{}//bench_1rm_respect
}