module.exports={
    post:()=>{},//dead_1rm_respect
    delete:()=>{}//dead_1rm_respect
}