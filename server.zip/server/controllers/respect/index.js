module.exports ={
    bench_1rm_respect:require('./bench1rmRespect'),
    dead_1rm_respect:require('./dead1rmRespect'),
    squat_1rm_respect:require('./squat1rmRespect'),
}