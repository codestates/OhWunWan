module.exports={
    post :()=>{},//ohwunwan_comment 작성
    patch :()=>{},//ohwunwan_comment 수정
    delete :()=>{},//ohwunwan_comment 삭제
}