module.exports={
    post :()=>{},//feedback_comment 작성
    patch :()=>{},//feedback_comment 수정
    delete :()=>{},//feedback_comment 삭제
}