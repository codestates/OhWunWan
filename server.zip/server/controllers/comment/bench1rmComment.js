module.exports={
    post :()=>{},//bench_1rm_comment 작성
    patch :()=>{},//bench_1rm_comment 수정
    delete :()=>{},//bench_1rm_comment 삭제
}