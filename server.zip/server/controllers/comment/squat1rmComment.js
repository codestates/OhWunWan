module.exports={
    post :()=>{},//squat_1rm_comment 작성
    patch :()=>{},//squat_1rm_comment 수정
    delete :()=>{},//squat_1rm_comment 삭제
}