module.exports={
    post :()=>{},//dead_1rm_comment 작성
    patch :()=>{},//dead_1rm_comment 수정
    delete :()=>{},//dead_1rm_comment 삭제
}