module.exports ={
    
    ohwunwan_comment:require('./ohwunwanComment.js'),
    feedback_comment: require('./feedbackComment'),
    bench_1rm_comment: require('./bench1rmComment.js'),
    dead_1rm_comment: require('./dead1rmComment.js'),
    squat_1rm_comment: require('./squat1rmComment.js'),
    
}